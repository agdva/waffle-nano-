from machine import I2C, Pin, PWM, SPI
import utime
from ds1307 import DS1307
import st7789

# 初始化 LED 点亮
led_pin = Pin(2, Pin.OUT)
led_pin.on()

# 初始化 TFT 屏幕
spi = SPI(0, baudrate=40000000, polarity=1, phase=0, bits=8, sck=Pin(6), mosi=Pin(8))
display = st7789.ST7789(spi, 240, 240, reset=Pin(11, Pin.OUT), dc=Pin(7, Pin.OUT))
display.init()

# 初始化 I2C 总线和 DS1307 对象
i2c = I2C(0, sda=Pin(13), scl=Pin(14), freq=400000)
rtc = DS1307(i2c)

# 初始化蜂鸣器 PWM 对象
buzzer_pin = Pin(12)
buzzer_pwm = PWM(3, buzzer_pin)
buzzer_pwm.init(freq=256, duty=0)

# 定义变量
cha = 0
threshold = 200

# 设置定时时间
trigger_time = (2023, 7, 27, 4, 16, 30, 0)
# 设置 DS1307 时钟模块的时间
rtc.set_time(trigger_time)
trigger_time = (2023, 7, 27, 4, 17, 30, 5)

# 定义 HX711 传感器连接的引脚
DT_PIN = 1  # G01 对应的引脚编号是 17
SCK_PIN = 0  # G00 对应的引脚编号是 16

# 若饮水量达到则灭灯
def check_and_turn_off_led(threshold):
    if cha >= threshold:
        led_pin.off()

# 循环播放三次无源蜂鸣器
def play_sound():
    for _ in range(3):
        buzzer_pwm.duty(95)
        buzzer_pwm.freq(1048)
        utime.sleep_ms(500)
        buzzer_pwm.duty(0)
        utime.sleep(0.5)
class HX711:
    def __init__(self, dout_pin, pd_sck_pin, gain=64):
        self.DOUT = Pin(dout_pin, Pin.IN)  # 使用整数引脚编号，G01对应引脚编号17
        self.PD_SCK = Pin(pd_sck_pin, Pin.OUT)  # 使用整数引脚编号，G00对应引脚编号16

        self.GAIN = 0
        self.REFERENCE_UNIT = 0.1

        self.OFFSET = 1
        self.OFFSET_B = 1
        self.lastVal = int(0)

        self.DEBUG_PRINTING = False

        self.bit_format = 'MSB'
        self.set_gain(gain)

        utime.sleep_ms(100)

    def set_gain(self, gain):
        if gain == 128:
            self.GAIN = 1
        elif gain == 64:
            self.GAIN = 3
        elif gain == 32:
            self.GAIN = 2

        self.PD_SCK.off()
        self.read_raw_bytes()

    def read_raw_bytes(self):
        # 等待HX711准备好可以读取数据。
        while self.DOUT.value() == 1:
            pass

        # 读取3个字节的数据。
        data = bytearray(3)
        for i in range(3):
            data[i] = 0
            for j in range(8):
                self.PD_SCK.on()
                bit_value = self.DOUT.value()
                self.PD_SCK.off()
                data[i] = (data[i] << 1) | bit_value

        # 设置增益和通道。
        for _ in range(self.GAIN):
            self.PD_SCK.on()
            self.PD_SCK.off()

        # 根据设置的位序返回数据。
        if self.bit_format == 'LSB':
            data = data[::-1]

        return data

    def read_average(self, times=10):
        total = 0
        for i in range(times):
            total += self.read_long()

        return total / times

    # 获取传感器的原始读数（可能是带符号的24位二进制补码值），然后将其转换为带符号的整数值
    def read_long(self):
        data = self.read_raw_bytes()

        twos_complement_value = ((data[0] << 16) | (data[1] << 8) | data[2])
        signed_int_value = self.convert_from_twos_complement24bit(twos_complement_value)

        self.lastVal = signed_int_value
        return int(signed_int_value)

    # 将24位二进制补码值（input_value）转换为带符号的整数值
    def convert_from_twos_complement24bit(self, input_value):
        return -(input_value & 0x800000) + (input_value & 0x7fffff)

    def get_weight(self, times=3):
        value = self.read_average(times)
        # 根据参考单位转换成实际重量值
        value = value / self.REFERENCE_UNIT
        return value
# 创建 HX711 传感器实例
hx711 = HX711(dout_pin=DT_PIN, pd_sck_pin=SCK_PIN)

# 测量对准
# 测量空载重量
print("空载时按下 Enter 键")
input()  # 等待用户按下 Enter 键
offset = hx711.read_average()

# 测量满载重量
print("满载时按下 Enter 键")
input()  # 等待用户按下 Enter 键
full_scale = hx711.read_average()

# 计算参考单位
known_weight = float(input("满载时的真实质量 "))
reference_unit = (full_scale - offset) / known_weight

# 输入个人信息
try:
    high = float(input("请输入你的身高（m）: "))
    weight = float(input("请输入你的体重（kg）： "))
    dengji = float(input("请输入你的运动等级强度（1，2，3）(从低到高)： "))
    if high < 1.3:
        liang = weight * (25 + dengji * 5)
    elif 1.3 <= high <= 1.7:
        liang = weight * (35 + dengji * 5)
    else:
        liang = weight * (45 + dengji * 5)
    yu = liang
    # 输出校准结果
    print("校准成功！")
    print("空载: {:.3f}".format(offset))
    print("满载: {:.3f}".format(full_scale))
    print("比例: {:.3f}".format(reference_unit))
    # 将校准结果保存在 HX711 实例中
    hx711.OFFSET = offset
    hx711.REFERENCE_UNIT = reference_unit
except ValueError:
    print("输入的不是数字")

# 进行循环
while True:
    # 获取初始称量值
    initial_weight = hx711.get_weight()
    utime.sleep(6)
    # 获取后续称量值
    final_weight = hx711.get_weight()
    # 计算称量前后的差值
    weight_difference = (initial_weight - final_weight) * 1000
    if weight_difference < 2 or weight_difference > 800:
        weight_difference = 0
    yu -= weight_difference
    cha += weight_difference
    # st7798 显示屏
    display.fill(st7789.color565(0, 0, 0))
    display.draw_string(0, 0, 'yu: {:.1f}ml'.format(yu), color=st7789.color565(66, 133, 244), bg=st7789.color565(66, 133, 244), size=3, vertical=False, rotate=st7789.ROTATE_0, spacing=1)
    # 设置时间间隔，单位为秒
    utime.sleep(1)

    # 设置定时触发时间
    current_time = rtc.get_time()
    print("Current Time:", current_time)
    # 将当前时间转换为时间戳
    # 将当前时间元组转换为长度为 8 的时间元组
    # 获取当前时间的时间戳
    current_timestamp = (current_time[0] - 1970) * 31536000 + \
                        (current_time[1] - 1) * 2592000 + \
                        (current_time[2] - 1) * 86400 + \
                        current_time[3] * 3600 + \
                        current_time[4] * 60 + \
                        current_time[5]
    # 将触发时间转换为时间戳
    trigger_timestamp = (trigger_time[0] - 1970) * 31536000 + \
                        (trigger_time[1] - 1) * 2592000 + \
                        (trigger_time[2] - 1) * 86400 + \
                        trigger_time[3] * 3600 + \
                        trigger_time[4] * 60 + \
                        trigger_time[5]
if current_timestamp >= trigger_timestamp:
    # 设置下一次触发时间（例如，加上2小时的时间间隔）
    trigger_timestamp += 60 * 60 * 2
    trigger_time = utime.localtime(trigger_timestamp)
    
    if cha < threshold:
        play_sound()
        # 重新点亮LED灯
        led_pin = Pin(2, Pin.OUT)
        led_pin.on()
        cha = 0

if cha > threshold:
    check_and_turn_off_led(threshold)
    cha = 0

utime.sleep(1)
